# 가계부(Budget-Log) 인수인계 메모

> 새 대화에서: "jaybaek-git/Budget-Log 의 HANDOFF.md 먼저 읽고 시작해 줘"
> 마지막 버전: **v1.3.1** (2026-11-20) — Baby-Log 구조를 그대로 따라 만듦

## 1. 무엇
- 부부 공유 가계부 웹앱 (PWA). https://jaybaek-git.github.io/Budget-Log/ (GitHub Pages, `main` 루트)
- 지출/수입 기록, 월 예산(전체+카테고리), 고정지출 자동 기록, 상대방 기록·예산 알림
- 구분: 하나의 가계부로 합산, 기록한 사람(`created_by`)만 표시

## 2. 작업 방식 (사용자 선호)
- 작은 수정은 v1.0.1, v1.0.2 …, 큰 기능은 v1.1
- 매 버전: `releases/Budget-Log_vX.zip` + `index.html`의 `APP_VERSION` + 커밋/푸시
- 더 좋은 방안이 있으면 선택지로 먼저 묻기 / UI 변경은 목업 먼저 요청할 때가 많음
- Supabase SQL은 Claude가 MCP로 직접 적용 → `supabase_vX_*.sql`로 저장소에도 남김
- 한국어, 모바일이라 짧게

## 3. 구조
### 프런트 (`index.html` 한 파일, 바닐라 JS)
- `h()` DOM 헬퍼, 차트는 SVG 문자열
- 폰별(localStorage): `bg_dev`(url/key/code/who), `bg_theme`, `bg_tab`, `bg_cache`, 로컬 모드 기록 `bg_tx`
- 공통(서버 `app_config.data`): `title`, `catVer`(2), `cats[]`(id, emoji, name, color, kind=out/in, budget, hidden, **subs[]** 세부 항목), `budget{total, alert}`, `liveNotify`
- 주요 함수: `refresh`, `renderSum`, `renderCats`, `renderList/Stats/Cal/Settings`, `openTx`(입력·수정), `openFixed`, `amountPad`(숫자패드), `openDay`
- 데이터는 보고 있는 달 기준 6개월치(`list_tx`)를 한 번에 불러옴
- 연결 코드 형식: `BUDGETLOG|url|key|code|who`

### 서버 (Supabase 프로젝트 `brnjahsragazesuqxtrd`, 이름 "jaybaek-git's Project", 도쿄)
- 무료 플랜 활성 프로젝트 2개 제한 → Baby-Log와 이 프로젝트 2개 사용 중
- 테이블: `tx`(kind, amount, cat, **sub**, at, memo, created_by, fixed_id), `fixed`(day, last_month …), `app_config`, `app_secret`(가족 코드·VAPID), `app_state`(edge_url, 예산 알림 단계), `push_subs`, `push_queue`
- RLS 켜고 직접 접근 막음 → `SECURITY DEFINER` RPC + `_chk(가족코드)`
- RPC: add_tx, update_tx(p_by), delete_tx(p_by), list_tx, import_tx, recent_log, month_totals, backup_now, list_backups, restore_backup, unskip_fixed, get_config, set_config, list_fixed, save_fixed, delete_fixed, save_push_sub, delete_push_sub, get_vapid_public, test_push
- 트리거 `_tx_notify`: 이번 달 기록이면 상대방 알림(본인 제외) + 예산 80/100% 알림(달마다 1번씩)
- pg_cron `budget-log-fixed`: 매일 00:05 KST `_run_fixed()` — 그 달 고정 항목을 날짜와 상관없이 모두 기록(tx.fixed_id+fixed_month 유일), 건너뛴 달(fixed_skip) 제외. 1일에 한 번 요약 알림
- 알림: `_push()` → push_queue → pg_net → Edge Function `push` (verify_jwt=false)

## 4. 함정 (Baby-Log와 같음)
- iOS 홈 화면 앱 키보드 안 뜸 → 숫자는 화면 숫자패드, 글자는 `prompt()`
- 웹 푸시는 홈 화면 앱에서만 (iOS 16.4+)
- Pages 반영 몇 분 + 홈 화면 앱 완전 종료 후 재실행, 설정 맨 아래 버전 확인
- 가족 코드·키는 저장소에 올리지 않음 (공개 저장소)

## 5. 앞으로 아이디어
- 카드 문자/알림 → 단축어로 자동 기록, Siri 음성 기록("커피 4500")
- 할부, 월 시작일(월급날 기준) 설정, 연간 통계

## 6. 버전 기록
- v1.0 (11/19) 첫 버전 / v1.0.1 화면 오류 표시
- v1.3.1 (11/20) 통계 일별 지출도 월별 추이처럼: 좌우 스크롤, 금액 표시, 고정 보라색, 누르면 아래에 그날 내역
- v1.3 (11/20) 변경 기록(tx_log) — 제목 아래 최근 변경 한 줄, 누르면 최근 40개 / 변경 알림을 바로 안 보내고 n분(설정 liveDelay, 기본 2분) 뒤 사람별로 묶어서 (새 변경 오면 다시 n분) / 서버 백업(매일 03:00 자동 30개 + 수동, 복원 시 '복원 전' 자동 백업) / 통계 '월별 추이' 전체 달 좌우 스크롤·누르면 그 달로(month_totals) — SQL `supabase_v1.3_log_backup.sql`
- v1.2.2 (11/20) 통계 카테고리별 지출 맨 아래에 고정지출 합계 행(중복 계산 없이 표시만, 누르면 항목 목록)
- v1.2.1 (11/20) 달력: 날짜 누르면 팝업 대신 달력 아래에 그날 내역 + 이 날 추가 버튼, 안 고르면 그 달 전체 내역 (같은 날 다시 누르면 전체로)
- v1.2 (11/20) 고정지출 개편 — 이번 달 것은 미래 날짜도 미리 기록(예정), 시작달·종료달(언제까지, 달력 선택), 세부 항목, 금액·날짜 바꾸면 "이번 달만 / 이번 달부터 계속" 선택, 이번 달 기록 지우면 그 달만 건너뜀(fixed_skip, 되살리기 가능), 요약에 고정/변동 따로, 내역 탭 위 고정지출 카드, 행에 '고정'·'예정' 배지, 달력 🔁 표시, 통계 '고정 n원 포함' — SQL `supabase_v1.2_fixed.sql`
- v1.1.3 (11/20) 시트: 제목·필터·버튼 고정, 내역만 스크롤, 짧으면 스크롤 없음, 뒤 화면 스크롤 잠금
- v1.1.2 (11/20) 통계 "내역 보기"를 시트로 (닫으면 통계 유지, 세부 필터)
- v1.1.1 (11/20) 통계에 카테고리 원(도넛) 그래프 — 조각 누르면 세부 펼침
- v1.1 (11/20) 사용자가 쓰던 가계부 앱 기준 카테고리 21개(카드대금·잔액조정 제외, 저축·대출은 지출로) + 세부 항목(선택), 첫 화면 5열로 전부 표시, 통계에서 카테고리 누르면 세부별 펼침, 카테고리 편집 시트 — SQL `supabase_v1.1_subcat.sql`

## 7. 카드 명세서로 기록하기 (Claude가 대신 입력)
- 사용자가 명세서 PDF·스크린샷을 보내면 Claude가 읽어 `import_tx`(알림 없음)로 넣음. 기록자 `삼성카드`
- '입금(취소), 포인트납부금액'은 **선결제** → 실제 지출로 기록. 회원할인으로 0원·취소 건은 제외. 할부는 이번 달 납부액만(메모에 회차)
- 모르는 항목은 추측해서 넣지 말고 **추측안을 선택지로 바로 물어보기** (사용자 요청)
- 11월 삼성카드분 입력 완료 (삼성전자 3건은 친구 물건이라 삭제). 네이버페이·쿠팡 건별 카테고리는 확인 대기

## 8. 등록된 고정지출 (2026-08 시작, 종료 없음 — 8~11월 모두 기록됨)
- 7일 쿠팡구독 7,890(통신비·구독) / 10일 승재보험 32,400(보험) / 14일 아이클라우드구독 11,100(통신비·구독) / 16일 승재통신비 47,940(통신비·휴대폰)
- 21일 승재청약저축 50,000(저축·청약), 승재보험 184,582(보험), 연금저축 380,000(저축·연금), 승재회비 50,000(회비·모임)
- 11/7 카드 명세서의 쿠팡 와우 7,890은 쿠팡구독 고정 기록으로 연결함 (중복 아님). 21일 4건·10/14/16일 건은 계좌이체라 카드 명세서에 안 나옴 (사용자 확인). 쿠팡구독만 카드 — 명세서 입력 때 겹치면 빼기
- 9월 삼성카드 명세서 입력 완료(61건). 그때 쿠팡 와우(9/7)·Apple 11,100(9/14)은 9월 고정 기록으로 연결
- **8·10월 명세서를 넣을 때**: 쿠팡 와우 7,890과 Apple 11,100(아이클라우드)은 이미 고정 기록으로 있으니 넣지 말 것 (중복)
- 9월 큰 쇼핑 4건(롯데아울렛·코치·갤러리아×2)은 임시로 의류&화장품 — 사용자 확인 대기
